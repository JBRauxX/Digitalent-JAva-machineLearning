/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tetek;

/**
 *
 * @author Lepi.0.1
 */
public class Tetek {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
          (origin)   
        root.setLeft(node2);
        node2.setLeft(node4);
        node2.setRight(node5);
        node5.setLeft(node7);
        root.setRight(node3);
        node3.setRight(node6);
        */
        
        node root = new node(1);
        node node2 = new node(2);
        node node3 = new node(3);
        node node4 = new node(4);
        node node5 = new node(5);
        node node6 = new node(6);
        node node7 = new node(7);              
        node node8 = new node(8);
        node node9 = new node(9);
        node node10 = new node(10);
        node node11 = new node(11);
        node node12 = new node(12);
        
   
        //set binary tree  Latihan2                 
        root.setLeft(node2);
        node2.setLeft(node3);
        node2.setRight(node4);
        node4.setLeft(node5);        
        node4.setRight(node7);
        node5.setLeft(node6);        
        node7.setLeft(node8);        
        root.setRight(node9);
        node9.setRight(node10);
        node10.setLeft(node11);
        node10.setRight(node12);
        /*
        //set binary tree  Latihan3                 
        root.setLeft(node2);
        root.setRight(node3);
        node2.setLeft(node4);
        node4.setRight(node7);
        node3.setLeft(node5);
        node3.setRight(node6);
        node5.setRight(node9);
        node5.setLeft(node8);
        */

        
        System.out.println("\r\nPreOrder");
        root.printPreOrder(root);
        
        System.out.println("\r\nInOrder");
        root.printInOrder(root);
        
        System.out.println("\r\nPostOrder ");
        root.printPostOrder(root);
        
    }
    
}
