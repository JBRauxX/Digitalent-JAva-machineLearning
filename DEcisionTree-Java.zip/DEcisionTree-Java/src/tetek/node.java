/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetek;

/**
 *
 * @author Lepi.0.1
 */
public class node {
    // properti node 
    int data;
    node left;
    node right;
    
    public node(int data){
        this.data = data;
        left = null;
        right = null;
    }
    
    public void setLeft(node node){
        if (left == null)
            left = node;
    }
    
    public void setRight(node node){
        if (right == null)
            right = node;
    }
    
    //return the current left node
    public node getLeft(){
        return left;
    }
    //return the current rioght node
    public node getRight(){
        return right;
    }
    
    public void setData(int data){
        this.data = data;
    }
    
    public int getData(){
        return data;
    }
    //preorder
    public void printPreOrder(node node){
        if (node == null)
            return;
        System.out.println(node.data + "");
        printPreOrder(node.left);
        printPreOrder(node.right);
    }
    
    //inorder     
    public void printInOrder(node node){
        if (node == null)
            return;
        printInOrder(node.left);
        System.out.println(node.data + "");
        printInOrder(node.right);
    }
    
    //postorder     
    public void printPostOrder(node node){
        if (node == null )
            return;
        printPostOrder(node.left);
        printPostOrder(node.right);
        System.out.println(node.data + "");
    }
}
