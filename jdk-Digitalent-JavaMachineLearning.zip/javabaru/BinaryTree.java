/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package adechandra.binarytree;

/**
 *
 * @author MI3 KOMPUTER
 */
public class BinaryTree {

   public static void main(String[] args) {

    // Testing tree traversals-----------------------------------------------------------------------------------------
    Node root = new Node(1);
    Node node2 = new Node(2);
    Node node3 = new Node(3);
    Node node4 = new Node(4);
    Node node5 = new Node(5);
    Node node6 = new Node(6);
    Node node7 = new Node(7);

    //menggambarkan tree 
    root.setLeft(node2); //2 
    node2.setLeft(node4); //4
    node2.setRight(node5);//5
    node5.setLeft(node7);//7
    root.setRight(node3);//3
    node3.setRight(node6);//6
    
    System.out.println("Inorder : ");
    root.printInorder(root);
    System.out.println();
    System.out.println("Postorder : ");
    root.printPostorder(root);
    System.out.println();
    System.out.println("Preorder : ");
    root.printPreorder(root);

    System.out.println();
    root.print();
    // ----------------------------------------------------------------------------------------------------------------
  }

}
