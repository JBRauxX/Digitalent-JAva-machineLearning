/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package adechandra.binarytree;

/**
 *
 * @author MI3 KOMPUTER
 */
public class TreeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Membuat Tree");
        BTree tree = new BTree();
        System.out.println("Hitung node dalam tree kosong");
        System.out.println(tree.countNodes());
        System.out.println("Membuat node dengan data : 1");
        Node root = new Node(1);
        System.out.println("Set node sebagai root");
        tree.setRoot(root);
        
        System.out.println("Hitung node dalam tree dengan node rootnya");
        System.out.println(tree.countNodes());
    //insert value node
        Node node2 = new Node(2);
        Node node3 = new Node(3);
        Node node4 = new Node(4);
        Node node5 = new Node(5);
        Node node6 = new Node(6);
        Node node7 = new Node(7);
        
        root.setLeft(node2); //2 
        node2.setLeft(node4); //4
        node2.setRight(node5);//5
        node5.setLeft(node7);//7
        root.setRight(node3);//3
        node3.setRight(node6);//6
        
        System.out.println("Set node setelah root");
        tree.setCurrent(tree.getRoot());
        System.out.println("Menampilkan current node");
        System.out.println(tree.getCurrent().getData());
        Node currentNode = tree.getCurrent();
        System.out.println("jumlah node dalam tree");
        System.out.println(tree.countNodes());
        
        System.out.println("In Order : ");
        tree.printInOrder();
        System.out.println("Pre Order : ");
        tree.printPreOrder();
        System.out.println("Post Order : ");
        tree.printPostOrder();
        System.out.println("Visualiasi BTree");
        tree.print();
    }
    
}
